/*
 var numbers = [Int]() //its an empty array
for i in 1...100{
    numbers.append(i) //Append stands for adding value in array
    print(i)
}
*/

var Names = ["Asif", "Rian"]
Names.count            //to count the variable
Names.isEmpty          //to check empty or not
Names.append("Yeasir") //to add variable
Names [0]
Names [1]
Names [2] = "Nusrat"   //replacing one value to another
Names.insert("Rahima", at: 3)
Names.insert("Rahima", at: 4) //add value by position

for i in Names{
    print(i)
}



