/*1.
for i in 1...100{
    print(i)
}
*/

/* 2.
for _ in 1...100{
    print("Hello World")
}
*/

/* 3.
var i = 1
while i <= 100{
    print(i)
    i += 1
}
*/

/* 4.
var i = 1
repeat {
    print(i)
    i += 1
}while i <= 100
*/

/* Problem
 
var i = 100
repeat{
    print(i)
    i = i-1
}while i <= 50
 
*/



