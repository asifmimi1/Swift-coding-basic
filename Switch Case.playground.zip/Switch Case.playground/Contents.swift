/* var myPokemon = "Messi"

switch (myPokemon) {
case "Pikachu":
    print("You got the right one")
case "Jigglypuff":
    print("You got a cute one")
default:
    print("You have got nothing")
}
*/


 /* var myCgpa = 2.33

switch (myCgpa) {
case 2.4..<2.99:
    print("Poor Cgpa")
case 2.9..<3.0:
    print("Not that bad")
case 3.0..<3.75:
    print("Healthy Cgpa")
case 3.75..<4.00:
    print("You are a Velka")
default:
    print("You are a peace of shit")
}
*/

var day = "Wednesday"
switch (day) {
case "Saturday":
    print("Start of the week")
case "Sunday":
    print("Second day of the week")
case "Monday":
    print("Third day the week")
case "Twesday":
    print("Fourth day of the week")
case "Wednesday":
    print("Fifth day of the week")
case "Thirsday":
    print("Sixth day of the week")
case "Friday":
    print("Last day of the week")
default:
    print("Not a day")
}





