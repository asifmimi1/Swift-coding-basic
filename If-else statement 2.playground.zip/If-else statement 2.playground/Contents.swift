//: Playground - noun: a place where people can play

var myAge = 9

if myAge >= 70 {
    print("You are not elegable for the ride")
}
else if myAge >= 18 {
    print("You are elegable for the ride")
}
else{
    print("you are not elegable for the ride")
}
